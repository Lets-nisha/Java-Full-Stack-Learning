import React, { useState,useMemo } from 'react'
import Fruits from './Fruits'

const App = () => {
  const [Count, setCount] = useState(0)
  // function data(){
  //   // function statement
  // }
  const data = useMemo(() => {
    const arr =['Mango', 'Banana', 'Apple', 'Guava']
    return arr
  }, [])
  return (
  <>
  <div>
    <h1>App Component</h1>
    <Fruits data={data}/>
    <h1>Count : {Count}</h1>
    <button onClick={()=>setCount((Count)=>Count+1)}>Increment</button>
  </div>
  </>
  )
}

export default App