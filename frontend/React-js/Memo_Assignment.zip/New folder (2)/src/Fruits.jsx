import React, { memo } from 'react'

const Fruits = ({data}) => {
    console.log(`Fruits child component Call...!`)
  return (
    <>
    <ul>
         {data.map((el, index)=><li key={index}>{el}</li>)}
    </ul>
   
    </>
  )
}

export default memo(Fruits) 